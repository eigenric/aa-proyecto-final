# Proyecto Final Asignatura AA 

Ricardo Ruiz Fernández de Alba y Daniel Navarrete Martín


## Instalación
Para instalar todas las librerías usadas, en caso de ser necesario,
utilizar el siguiente comando:
$ pip install -r requirements.txt
